# Multivariate Analysis Practice Simulated Data

This folder contains simulated data that matches the structure of the past paper.

Files:

1. data/data_tidy_stress.csv
   - 500 individuals
   - Variables: age, income, satisfaction, experience, hours, stress
   - Use for PCA, reconstruction, correlations between PCs and variables, and factor analysis.

2. data/data_tidy_lum_response.csv
   - 100 individuals
   - pid plus 15 immune response variables:
     crp, ddimer, ferritin, ifng, il10, il12p70, il13, il1ra,
     mcp1, mip1a, mip1b, tnf, vegf, scd14, scd40l
   - Use for multivariate regression, PCR, PLS, CCA and LDA.

3. data/data_tidy_lum_meta.csv
   - pid plus demographic variables:
     infxn, age, sex, ethnicity, household_size
   - Use for correspondence analysis and for creating age_infxn groups.

4. practice_starter_code.R
   - Starter R code for the same sections as the past paper.

Suggested practice:
- Analysis I: PCA from first principles + factor analysis.
- Question 2.1: CA of age by ethnicity.
- Question 2.2: multivariate regression + PCR with princomp + first PLS component.
- Question 2.3: CCA between crp:il1ra and mcp1:scd40l.
- Question 2.4: LDA plot for age_infxn groups using immune response variables.