# ============================================================
# Multivariate Analysis Practice Data
# Simulated to match the structure of the past paper
# ============================================================

library(dplyr)
library(ggplot2)
library(knitr)

# Load data
data_tidy_stress <- read.csv(file.path("data", "data_tidy_stress.csv"))
data_tidy_lum_response <- read.csv(file.path("data", "data_tidy_lum_response.csv"))
data_tidy_lum_meta <- read.csv(file.path("data", "data_tidy_lum_meta.csv"))

# Merge immune response and metadata
data_tidy_lum <- data_tidy_lum_meta |>
  left_join(data_tidy_lum_response, by = "pid") |>
  mutate(age_infxn = paste0(age, "_", infxn)) |>
  select(pid:household_size, age_infxn, everything())

# ============================================================
# Section 1 practice: PCA + factor analysis
# ============================================================

# Standardise stress data
stress_std <- scale(data_tidy_stress)

# PCA using covariance matrix of standardised data
S <- cov(stress_std)
eig <- eigen(S)
loadings <- eig$vectors
scores <- stress_std %*% loadings
prop_var <- eig$values / sum(eig$values)

kable(round(loadings[, 1:3], 3))
kable(round(head(scores[, 1:3]), 3))
round(prop_var, 3)

plot(prop_var, type = "b",
     xlab = "Principal component",
     ylab = "Proportion of variation explained")

# Factor analysis with two factors
fa_fit <- factanal(stress_std, factors = 2, scores = "regression")
print(fa_fit)
plot(fa_fit$scores[,1], fa_fit$scores[,2],
     xlab = "Factor 1", ylab = "Factor 2")

# ============================================================
# Section 2.1 practice: Correspondence analysis
# ============================================================

tab_age_eth <- table(data_tidy_lum_meta$age, data_tidy_lum_meta$ethnicity)
tab_age_eth

# You can use ca::ca(tab_age_eth), or do CA from first principles.

# ============================================================
# Section 2.2 practice: multivariate regression + PCR + PLS
# ============================================================

# Multivariate regression with crp and ddimer as responses
Y <- data_tidy_lum_response |>
  select(crp, ddimer) |>
  as.matrix()

X <- data_tidy_lum_response |>
  select(ifng, il10) |>
  as.matrix()

X_int <- cbind(intercept = 1, X)

B_hat <- solve(t(X_int) %*% X_int) %*% t(X_int) %*% Y
kable(round(B_hat, 3))

# PCR diagnostic using princomp
y <- data_tidy_lum_response$crp
X_pcr <- data_tidy_lum_response |>
  select(-pid, -crp)

pcr_pc <- princomp(X_pcr, cor = TRUE)
summary(pcr_pc)

pc_scores <- pcr_pc$scores
round(cor(y, pc_scores[, 1:5]), 3)

m <- 2
pcr_fit <- lm(y ~ pc_scores[, 1:m])
summary(pcr_fit)

# First PLS component from first principles
y_std <- as.numeric(scale(y))
X_pls <- data_tidy_lum_response |>
  select(-pid, -crp) |>
  as.matrix()

X_std <- scale(X_pls)

w1 <- t(X_std) %*% y_std
w1 <- w1 / sqrt(sum(w1^2))

z1 <- X_std %*% w1

cor(z1, y_std)

pls_weights <- data.frame(
  variable = colnames(X_std),
  weight = as.numeric(w1)
)

kable(pls_weights, digits = 3)

# ============================================================
# Section 2.3 practice: Canonical correlation analysis
# ============================================================

lum_response_mat_std <- data_tidy_lum_response |>
  select(crp:scd40l) |>
  mutate(across(everything(), ~ (. - mean(.))/sd(.))) |>
  as.matrix()

X1 <- lum_response_mat_std[, c("crp", "ddimer", "ferritin", "ifng", "il10", "il12p70", "il13", "il1ra")]
X2 <- lum_response_mat_std[, c("mcp1", "mip1a", "mip1b", "tnf", "vegf", "scd14", "scd40l")]

cc_fit <- cancor(X1, X2)
cc_fit$cor

# Fourth canonical variates
u4 <- X1 %*% cc_fit$xcoef[, 4]
v4 <- X2 %*% cc_fit$ycoef[, 4]
cor(u4, v4)

# Regress fourth right-canonical variate against original left set
fit_cc <- lm(v4 ~ X1)
cor(fitted(fit_cc), v4)

# ============================================================
# Section 2.4 practice: LDA / discriminant plot
# ============================================================

library(MASS)

lda_dat <- data_tidy_lum |>
  select(age_infxn, crp:scd40l)

lda_fit <- lda(age_infxn ~ ., data = lda_dat)
lda_pred <- predict(lda_fit)

plot(lda_pred$x[,1], lda_pred$x[,2],
     col = as.numeric(lda_dat$age_infxn),
     pch = 19,
     xlab = "LD1", ylab = "LD2")
legend("topright",
       legend = levels(factor(lda_dat$age_infxn)),
       col = seq_along(levels(factor(lda_dat$age_infxn))),
       pch = 19,
       cex = 0.6)

# Loadings / coefficients
kable(round(lda_fit$scaling[, 1:2], 3))